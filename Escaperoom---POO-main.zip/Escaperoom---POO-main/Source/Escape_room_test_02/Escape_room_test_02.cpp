// Copyright Epic Games, Inc. All Rights Reserved.

#include "Escape_room_test_02.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Escape_room_test_02, "Escape_room_test_02" );
