// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Escape_room_test_02GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class ESCAPE_ROOM_TEST_02_API AEscape_room_test_02GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
